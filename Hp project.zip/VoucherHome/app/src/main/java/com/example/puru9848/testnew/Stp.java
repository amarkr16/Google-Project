package com.example.puru9848.testnew;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

/**
 * Created by puru9848 on 05-11-2016.
 */
public class Stp extends AppCompatActivity{

    private CollapsingToolbarLayout collapsingToolbarLayout = null;
    
    Toolbar toolbar;


    private Button getr;
    private AlertDialog.Builder checkbuilder;
    private static long back_pressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stp);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);





        collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        collapsingToolbarLayout.setTitle(getResources().getString(R.string.user_name));
       // collapsingToolbarLayout.setVisibility(View.INVISIBLE);

        dynamicToolbarColor();

        toolbarTextAppernce();
    }


    private void dynamicToolbarColor() {

        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.bitmesra);
    }


    private void toolbarTextAppernce() {
        collapsingToolbarLayout.setCollapsedTitleTextAppearance(R.style.collapsedappbar);
        collapsingToolbarLayout.setExpandedTitleTextAppearance(R.style.expandedappbar);
    }

    public void getr(View view) {


        if (!isNetworkAvailabe()) {


            // startActivity(new Intent(MainActivity.this, Itsyllabus.class));


            checkbuilder = new AlertDialog.Builder(Stp.this);
            checkbuilder.setIcon(R.drawable.ic_error_black_24dp);
            checkbuilder.setTitle("Error");
            checkbuilder.setMessage("No Internet Connection");



            checkbuilder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                }



            });



            AlertDialog alertdialog = checkbuilder.create();
            alertdialog.show();
        } else {

            if (isNetworkAvailabe()) {

                startActivity(new Intent(Stp.this, Getr.class));
            }
        }
    }


    private boolean isNetworkAvailabe(){

        ConnectivityManager coonnectivityManager = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activenetworkInfo = coonnectivityManager.getActiveNetworkInfo();
        return activenetworkInfo != null;
    }
}
