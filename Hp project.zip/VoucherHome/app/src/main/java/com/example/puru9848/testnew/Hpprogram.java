package com.example.puru9848.testnew;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by puru9848 on 05-11-2016.
 */
public class Hpprogram  extends AppCompatActivity{

    Toolbar toolbar;
    private LinearLayout l1,l2,l3,l4,l5,l6,bb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hpprogram);



        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        l1 = (LinearLayout)findViewById(R.id.l1);
        l2 = (LinearLayout)findViewById(R.id.l2);
        l3 = (LinearLayout)findViewById(R.id.l3);
        l4 = (LinearLayout)findViewById(R.id.l4);
        l5 = (LinearLayout)findViewById(R.id.l5);
        l6 = (LinearLayout)findViewById(R.id.l6);


        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent three = new Intent(Hpprogram.this,Stp.class);
                startActivity(three);
            }
        });

        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent three = new Intent(Hpprogram.this,Wtp.class);
                startActivity(three);
            }
        });

        l3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent three = new Intent(Hpprogram.this,Pbtb.class);
                startActivity(three);
            }
        });

        l4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent three = new Intent(Hpprogram.this,Ctp.class);
                startActivity(three);
            }
        });

        l5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent three = new Intent(Hpprogram.this,Itp.class);
                startActivity(three);
            }
        });

        l6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent three = new Intent(Hpprogram.this,Crt.class);
                startActivity(three);
            }
        });

    }
}
