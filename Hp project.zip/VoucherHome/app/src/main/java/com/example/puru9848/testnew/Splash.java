package com.example.puru9848.testnew;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by puru9848 on 05-11-2016.
 */
public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);


        new LaunchScreen().execute("Exception");
    }


    private class LaunchScreen extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            for (int i = 0; i < 3; i++)
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.interrupted();

                }
            return "Exception";
        }

        @Override
        protected void onPostExecute(String s) {
            Intent getNameScreenIntent = new Intent(getBaseContext(), Login.class);
            startActivity(getNameScreenIntent);
            Splash.this.finishAffinity();
        }
    }
}
