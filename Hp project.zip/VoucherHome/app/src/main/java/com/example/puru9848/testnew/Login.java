package com.example.puru9848.testnew;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

/**
 * Created by puru9848 on 05-11-2016.
 */
public class Login extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);


        final Animation animTranslate = AnimationUtils.loadAnimation(this,
                R.anim.anim_translate);


        Button pk = (Button) findViewById(R.id.signin);
        pk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animTranslate);
                v.postDelayed(new Runnable() {
                    @Override
                    public void run() {


                        Intent puru = new Intent(Login.this, MainActivity.class);
                        startActivity(puru);


                    }
                }, 200);

            }
        });



    }


}
