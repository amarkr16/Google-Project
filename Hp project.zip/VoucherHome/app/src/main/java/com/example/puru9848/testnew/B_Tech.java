package com.example.puru9848.testnew;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by puru9848 on 11-08-2016.
 */
public class B_Tech extends ActionBarActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.b_tech);
    }
}
